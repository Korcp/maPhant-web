import React from "react";
import "./Signup.css";
import { Link } from "react-router-dom";

function Signup() {
  return (
    <div>
      <nav>
        <div className="ID">
          <label>아이디</label>
        </div>
        <div className="IDtextbox">
          <input
            id="input"
            type="text"
            placeholder="4~15 이내로 입력해주세요"
          />
          <br />
        </div>
        <div className="PWN">
          <label>비밀번호</label>
        </div>
        <div className="PWtextbox">
          <input
            type="password"
            id="password"
            placeholder=" 최소 6자 이상(알파벳,숫자 필수)"
          />
          <br />
        </div>
        <div className="Email">
          <label>이메일</label>
        </div>
        <div className="Emailtextbox">
          <input type="email" id="email" placeholder=" abc123@gwakkii.co.kr" />
          <br />
        </div>
        <div className="Name">
          <label>실명</label>
        </div>
        <div className="Nametextbox">
          <input type="text" id="name" placeholder=" 홍길동" />
          <br />
        </div>
        <div className="Nickname">
          <label>닉네임</label>
        </div>
        <div className="Nicknametextbox">
          <input
            id="input"
            type="text"
            placeholder="4~15 이내로 입력해주세요"
          />
          <br />
        </div>
        <br />
        <button type="submit">회원가입</button>
      </nav>
    </div>
  );
}

export default Signup;
